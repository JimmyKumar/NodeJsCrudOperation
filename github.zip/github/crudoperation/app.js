// Step 1 - set up express & mongoose

var express = require('express')
var app = express()
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
let pdf = require("html-pdf");
const PDFDocument = require('pdfkit');
var fs = require('fs');
let ejs = require("ejs");
var path = require('path');
require('dotenv/config');
var nodemailer = require('nodemailer');
//Checking the crypto module
const crypto = require('crypto');
const algorithm = 'aes-256-cbc'; //Using AES encryption
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);
// Step 3 - code was added to ./models.js

// Step 4 - set up EJS

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

// Set EJS as templating engine
app.set("view engine", "ejs");
// Step 2 - connect to the database

mongoose.connect(process.env.MONGO_URL,
	{ useNewUrlParser: true, useUnifiedTopology: true }, err => {
		console.log('connected')
	});

    // Step 9 - configure the server's port

var port = process.env.PORT || '8000'
app.listen(port, err => {
	if (err)
		throw err
	console.log('Server listening on port', port)
})

// Step 5 - set up multer for storing uploaded files

var multer = require('multer');

var storage = multer.diskStorage({
	destination: (req, file, cb) => {
		cb(null, 'uploads')
	},
	filename: (req, file, cb) => {
		cb(null, file.fieldname + '-' + Date.now())
	}
});

var upload = multer({ storage: storage });

// Step 6 - load the mongoose model for Image

var imgModel = require('./models');

//Encrypting text
function encrypt(text) {
	let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
	let encrypted = cipher.update(text);
	encrypted = Buffer.concat([encrypted, cipher.final()]);
	return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
 }
 
 // Decrypting text
 function decrypt(text) {
	let iv = Buffer.from(text.iv, 'hex');
	let encryptedText = Buffer.from(text.encryptedData, 'hex');
	let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);
	let decrypted = decipher.update(encryptedText);
	decrypted = Buffer.concat([decrypted, decipher.final()]);
	return decrypted.toString();
 }

// Step 7 - the GET request handler that provides the HTML UI

app.get('/', (req, res) => {
	imgModel.find({}, (err, items) => {
		if (err) {
			console.log(err);
			res.status(500).send('An error occurred', err);
		}
		else {
			res.render('imagesPage', { items: items });
		}
	});
});
app.get("/exportpdf", (req, res) => {
	imgModel.find({}, (err, items) => {
		if (err) {
			console.log(err);
			res.status(500).send('An error occurred', err);
		}
		else {
			
			ejs.renderFile(path.join(__dirname, './views/', "template.ejs"), {items: items}, (err, data) => {
				if (err) {
					  res.send(err);
				} else {
					let options = {
						"height": "11.25in",
						"width": "8.5in",
						"header": {
							"height": "20mm"
						},
						"footer": {
							"height": "20mm",
						},
					};
					pdf.create(data, options).toFile("report.pdf", function (err, data) {
						if (err) {
							res.send(err);
						} else {
							res.send("File created successfully");
						}
					});
				}
			});

		}
	});
    
});
// app.get('/exportpdf', (req, res) => {
// 	imgModel.find({}, (err, items) => {
// 		if (err) {
// 			console.log(err);
// 			res.status(500).send('An error occurred', err);
// 		}
// 		else {
// 			let pdfDoc = new PDFDocument;
// 			pdfDoc.pipe(fs.createWriteStream('lists.pdf'));
// 			const pdfArr = []

// 			items.forEach(s => {
// 			let p = new PDFDocument();
// 			p.pipe(fs.createWriteStream(`lists.pdf`))
// 			p.fontSize(25).text(`Hello ${s.name}`, 100, 100)
// 			p.end();

// 			pdfArr.push(p);

// 			});
// 			pdfDoc.list(pdfArr);

// 			pdfDoc.end();

// 			res.redirect('/');
// 		}
// 	});
// });

app.get('/edit/:id', async(req, res) => {
	let {params}=req;
//findByIdAndUpdate
try {
    const updatedResult =await imgModel.findByIdAndUpdate(
      { _id: params.id },
      {
        profession: "full-stack Developer",
      },
      {
        new: true,
        upsert: true,
      }
    );
	res.render('edit', { item: updatedResult });
    console.log(updatedResult);
  } catch (error) {
    console.log(error);
  }
});

app.post('/edit', upload.single('image'), (req, res, next) => {

	var obj = {
		name: req.body.name,
		email: req.body.email,
		password: encrypt(req.body.password).encryptedData,
		img: {
			data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)),
			contentType: 'image/png'
		}
	}
	imgModel.updateOne(obj, (err, item) => {
		if (err) {
			console.log(err);
		}
		else {
			// item.save();
			res.redirect('/');
		}
	});
});

// DELETE USER
app.get('/delete/(:id)', function(req, res, next) {
    imgModel.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            res.redirect('/');
        } else {
            console.log('Failed to Delete user Details: ' + err);
        }
    });
});

app.get('/sendmail', function(req, res, next) {
    var transporter = nodemailer.createTransport({
		service: 'gmail',
		auth: {
		  user: 'jimmyantech@gmail.com',
		  password: 'Kumar#006'
		},
		host: 'smtp.gmail.com',
		port: 587,
		secure: false,
	  });
	  
	  var mailOptions = {
		
		from: 'jimmyantech@gmail.com',
		to: 'jimmy@antiersolutions.com',
		subject: 'Sending Email using Node.js',
		text: 'That was easy!'
	  };
	  
	  transporter.sendMail(mailOptions, function(error, info){
		if (error) {
		  console.log(error);
		} else {
		  console.log('Email sent: ' + info.response);
		}
	  });
});

// Step 8 - the POST handler for processing the uploaded file

app.post('/', upload.single('image'), (req, res, next) => {

	var obj = {
		name: req.body.name,
		email: req.body.email,
		password: encrypt(req.body.password).encryptedData,
		img: {
			data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)),
			contentType: 'image/png'
		}
	}
	imgModel.create(obj, (err, item) => {
		if (err) {
			console.log(err);
		}
		else {
			// item.save();
			res.redirect('/');
		}
	});
});



